# Databricks notebook source
dbutils.fs.ls('abfss://demo@databrickscourseucextdl.dfs.core.windows.net/')

# COMMAND ----------

