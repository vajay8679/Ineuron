-- Databricks notebook source
SELECT *
  FROM formula1_dev.information_schema.tables
 WHERE table_name = 'results';

-- COMMAND ----------

